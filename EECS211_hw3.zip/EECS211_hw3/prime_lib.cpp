#include "prime_lib.h"

#include <stdexcept>
#include <vector>
//#include <bits/valarray_before.h>

using namespace std;

bool is_prime(int p) {
    if (p < 1) {
        throw runtime_error("is_prime given negative value");
    }

    int i;
    bool is_Prime = true;

    for (i = 2; i < p; ++i) {
        if (p % i == 0) {
            is_Prime = false;
            break;
        }
    }

    if (p == 1) {
        is_Prime = false;
    }

    return is_Prime;
}

bool check_is_prime(const std::vector<int> &primes, int p) {
    if (p < 1) {
        throw runtime_error("check_is_prime given negative value");
    }

    if(primes.size() == 0){
        throw runtime_error("vector of primes given to check_is_prime is empty");
    }

    bool result = true;

    for (int prime : primes) {
        if (p == prime) {
            break;
        } else if (p % prime == 0) {
            result = false;
        }

    }

    if(p == 1)
        result = false;

    return result;
}

//vector<int> generate_primes(int n) {
//    if (n < 1) {
//        throw runtime_error("generate_primes given negative value");
//    }
//
//    vector<int> primes;
//    vector<bool> sieve;
//
//    for (int h = 0; h <= n; ++h) {
//        sieve.push_back(true);
//    }
//
//    for (int i = 2; i < n; ++i) {
//        if (sieve[i - 2]) {
//            for (int ii = 2; ii < n / i; ++ii) {
//                sieve[i * ii] = false;
//            }
//        }
//    }
//    for (int j = 0; j <= n; ++j) {
//        if (sieve[j]) {
//            primes.push_back(j + 2);
//        }
//    }
//    return primes;
//}

vector<int> generate_primes(int n) {
    if (n < 1) {
        throw runtime_error("generate_primes given negative value");
    }

    vector<int> primes;
    vector<bool> sieve {false, false};

    for (int h = 0; h < n; ++h) {
        sieve.push_back(true);
    }

    for(int i = 0; i < n; ++i) {
        if (sieve[i]) {
            for (int ii = 2; ii <= n / i; ++ii) {
                sieve[i*ii] = false;
           }
        }
    }

    for (int j = 0; j <= n; ++j) {
        if (sieve[j]) {
            primes.push_back(j);
        }
    }

    return primes;
}