# IPD project configuration

This directory contains files for configuring this IPD project:

    CMakeLists.txt - common macro definitions

    README.md - this file

    lib/ - included libraries

        unittest-cpp/ - testing framework

You probably shouldn’t change anything here. Since the course staff
might change it at will, you should be prepared for merge conflicts.
