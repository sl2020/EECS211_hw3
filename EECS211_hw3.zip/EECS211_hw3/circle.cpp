#include "circle_lib.h"

#include <iostream>
#include <vector>

using namespace std;

int main()
{
  // [YOUR HW2 CODE HERE]

  return 0;
}
