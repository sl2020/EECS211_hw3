#include "circle_lib.h"

#include <iostream>
#include <vector>

using namespace std;

int main()
{
  Circle circle1, circle2;
  circle1 = read_circle();
  circle2 = read_circle();
  vector<Circle> circles;

  while(circle2.radius > 0){
    circles.push_back(circle2);
    circle2 = read_circle();
  }

  for(size_t i = 0; i<circles.size(); ++i){
    if(overlapped(circle1, circles[i]))
      cout<<"overlapped\n";
    else
      cout<<"not overlapped\n";
  }

  return 0;
}
