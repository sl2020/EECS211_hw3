#include "prime_lib.h"

#include <UnitTest++/UnitTest++.h>
#include <stdexcept>
#include <vector>


using namespace std;

TEST(IS_PRIME)
{
    CHECK_EQUAL(false,is_prime(1));
    CHECK_EQUAL(true,is_prime(2));
    CHECK_EQUAL(true,is_prime(3));
    CHECK_EQUAL(false,is_prime(4));
    CHECK_EQUAL(true,is_prime(5));
    CHECK_EQUAL(true,is_prime(7));
    CHECK_EQUAL(false,is_prime(8));
    CHECK_EQUAL(false,is_prime(2*83));
}

TEST(IS_PRIME_ERRORS)
{
    CHECK_THROW(is_prime(0), runtime_error);
    CHECK_THROW(is_prime(-15), runtime_error);
}

// Write unit tests for generate_primes
// [YOUR CODE HERE]
TEST(GENERATE_PRIMES)
{
    vector<int> v1 = {2, 3, 5, 7};
    CHECK_ARRAY_EQUAL(v1, generate_primes(8), generate_primes(8).size());
    CHECK_ARRAY_EQUAL(v1, generate_primes(7), generate_primes(7).size());
}

TEST(GENERATE_PRIME_ERRORS)
{
    CHECK_THROW(generate_primes(-5), runtime_error);
    CHECK_THROW(generate_primes(0), runtime_error);
}

// Write unit tests for check_is_prime
// [YOUR CODE HERE]
TEST(CHECK_IS_PRIME)
{
    vector<int> test2 = {2,3,5};
    CHECK_EQUAL(false, check_is_prime(test2, 1));
    CHECK_EQUAL(true, check_is_prime(test2, 2));
    CHECK_EQUAL(true, check_is_prime(test2, 3));
    CHECK_EQUAL(false, check_is_prime(test2, 4));
    CHECK_EQUAL(true, check_is_prime(test2, 5));

    vector<int> test1 = {2,3,5,7,11,13,17,19,23,29,31};
    CHECK_EQUAL(false, check_is_prime(test1, 4));
    CHECK_EQUAL(true, check_is_prime(test1, 13));
    CHECK_EQUAL(true, check_is_prime(test1, 59));

    CHECK_EQUAL(is_prime(1), check_is_prime(test2, 1));
    CHECK_EQUAL(is_prime(2), check_is_prime(test2, 2));
    CHECK_EQUAL(is_prime(3), check_is_prime(test2, 3));
    CHECK_EQUAL(is_prime(4), check_is_prime(test2, 4));
    CHECK_EQUAL(is_prime(5), check_is_prime(test2, 5));

}
TEST(CHECK_IS_PRIME_ERRORS)
{
    vector<int> test1 = {2,3,5,7,11,13,17,19,23,29,31};
    CHECK_THROW(check_is_prime(test1, -3), runtime_error);
    CHECK_THROW(check_is_prime(test1, 0), runtime_error);
}

