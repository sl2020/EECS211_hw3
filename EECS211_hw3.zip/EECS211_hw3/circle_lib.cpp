#include "circle_lib.h"

#include <iostream>
#include <stdexcept>

using namespace std;

Circle read_circle()
{
  // [YOUR HW2 CODE HERE]
}

bool overlapped(Circle c1, Circle c2)
{
  // [YOUR HW2 CODE HERE]
}

