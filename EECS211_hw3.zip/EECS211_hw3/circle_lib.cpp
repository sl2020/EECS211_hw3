#include "circle_lib.h"

#include <iostream>
#include <stdexcept>
#include <cmath>

using namespace std;

Circle read_circle()
{
    double x, y, radius;
    cin>>x>>y>>radius;
    Circle circ = {x, y, radius};
    return circ;
}

bool overlapped(Circle C1, Circle C2)
{
    if(C1.radius < 0 || C2.radius < 0){
        throw runtime_error("One or both of the radii are negative");
    }

    double radius_lengths = C1.radius + C2.radius;
    double distance = sqrt(pow((C2.x-C1.x), 2)+pow((C2.y-C1.y), 2));

    return radius_lengths>distance;
}

