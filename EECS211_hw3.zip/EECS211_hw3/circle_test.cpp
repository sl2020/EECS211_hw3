#include "circle_lib.h"

#include <UnitTest++/UnitTest++.h>
#include <stdexcept>

using namespace std;

TEST(OVERLAPPED)
{
  // [YOUR CODE HERE]
}

TEST(OVERLAPPED_ERROR)
{
  // [YOUR CODE HERE]
}

