#include "circle_lib.h"

#include <UnitTest++/UnitTest++.h>
#include <stdexcept>

using namespace std;

TEST(OVERLAPPED)
{
    Circle c1{0,0,1};
    Circle c2{5,5,1};
    Circle c3{2,0,1};
    Circle c4{1,0,1};

    CHECK_EQUAL(false, overlapped(c1,c2));
    CHECK_EQUAL(true, overlapped(c1, c4));
    CHECK_EQUAL(false, overlapped(c3, c1));
}

TEST(OVERLAPPED_ERROR)
{
    Circle c1{6,12,-1};
    Circle c2{5,5,-1};
    Circle c3{0,0,1};
    CHECK_THROW(overlapped(c1, c2), runtime_error);
    CHECK_THROW(overlapped(c2, c3), runtime_error);
    CHECK_THROW(overlapped(c1, c3), runtime_error);
}

